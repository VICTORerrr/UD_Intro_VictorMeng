# UD_IntroProject_2023

The central place for all material regarding the B-Pro UD introduction project for the academic year 2023/2022

----

All meetings will be on Zoom, details are on Teams. 

----
# Schedule
__Monday__: 14:00 - 2/10: __Introduction__

__Recording__
https://ucl.zoom.us/rec/share/1UEa4OVSvDGR8TVTrk12rRrXxLz7aM9BI9hmr1sHCrZW7yjDJty5550rHzbqfbE9.haMQzIjoNmNM2mmk
Passcode: `=M#dp#j8`

- What is programming, Variables, Loops
    - Text based assignments for Wednesday

__Tuesday__: - 3/10: _seminar_
- Check Installation, help with questions

__Wednesday__: 11:00 - 4/10: __Session 1__
- Functions, Lists, Arrays, Read and Write to files
    - Instruct Wall-E Assignment for Friday
    - Text based assignment for Friday

__Thursday__: - 5/10: _seminar_
- Help with questions

__Friday__: TBD - 6/10: __Session 2__
- Web scraping in Selenium
    - Final web scraping assignment for Tuesday 10/10

__Monday__: - 9/10: _seminar_
- Help with questions

__Tuesday__: - 14:00 - 10/10: __Presentation of final assignment__
